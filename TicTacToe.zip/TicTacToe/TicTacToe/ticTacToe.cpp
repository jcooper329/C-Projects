//main program
#include <iostream>
#include "ticTacToe.h"

using namespace std;

int main()
{
	char ans = ' ';
	int hold = 0;
	ticTacToe game;
	do {
		game.play();
		cout << "Would you like to play again?(y/n): ";
		cin >> ans;
		game.reStart();
	} while (ans == 'y' || ans == 'Y');

	cin >> hold;
	return 0;
}