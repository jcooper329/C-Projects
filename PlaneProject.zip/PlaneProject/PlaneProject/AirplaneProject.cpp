﻿/*
Name: Justin Cooper
Date: 10.09.2018
Desc: Selling airplane tickets for Airbus A220
*/

#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
#include <limits>
#include <stdlib.h>

using namespace std;

//function prototypes
void firstClass();
void business();
void economy();
void seatChoice();
void seatLayout(char seats[17][6]);
void display();
void returnSeat();

//variables
char plane[17][6];
int ftickets = 0;
int btickets = 0;
int etickets = 0;
int ftotal = 0;
int btotal = 0;
int etotal = 0;
int total = 0;

int main()
{
	//variables
	int hold = 0;

	//calls functions
	seatLayout(plane);
	seatChoice();
	cout << "You bought " << ftickets << " First Class tickets for $" << ftotal << endl;
	cout << "You bought " << btickets << " Business tickets for $" << btotal << endl;
	cout << "You bought " << etickets << " Economy tickets for $" << etotal << endl;
	cout << "Your overall total is $" << total << "! Please pay now!" << endl;
	cin >> hold;
	return 0;
}

void seatLayout(char seats[17][6])
{
	int num = 1;
	for (int i = 0; i < 17; i++)
	{
		for (int k = 0; k < 6; k++)
		{
			seats[i][k] = '*';
		}
	}
	cout << "    A B C   D E F" << endl;
	for (int i = 0; i < 17; i++)
	{
		if (num < 10)
			cout << num << "   ";
		else
			cout << num << "  ";
		num++;
		for (int k = 0; k < 6; k++)
		{
			cout << seats[i][k] << ' ';
			if (k == 2)
				cout << "  ";
		}
		cout << endl;
	}
}

void seatChoice()
{
	//variables
	int choice = 0;
	int col = 0;
	char row = ' ';
	char ans = ' ';
	//user interaction
	cout << "Would you like to purchase a seat?" << endl;
	do
	{
		cout << "1. First Class - $1500.00" << endl;
		cout << "2. Business - $700.00" << endl;
		cout << "3. Economy - $200.00" << endl;
		cout << "4. Return" << endl;
		cin >> choice;
		while (cin.fail() || choice < 1 || choice > 4)
		{
			cout << "Try again: ";
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cin >> choice;
		}
		switch (choice)
		{
			case 1:
			{
				firstClass();
				break;
			}
			case 2:
			{
				business();
				break;
			}
			case 3:
			{
				economy();
				break;
			}
			case 4:
			{
				returnSeat();
				break;
			}
		}
		cout << "Would you like another ticket?(y/n)\n";
		cin >> ans;
	}while (ans == 'y' || ans == 'Y');
}
void display() //displays seats
{
	//variables
	int num = 1;
	//displays letters
	cout << "    A B C   D E F" << endl;
	for (int i = 0; i < 17; i++)
	{
		if (num < 10)
			cout << num << "   ";
		else
			cout << num << "  ";
		num++;
		for (int k = 0; k < 6; k++)
		{
			cout << plane[i][k] << ' ';
			if (k == 2)
				cout << "  ";
		}
		cout << endl;
	}
}

void firstClass()
{
	//variables
	char checkLetter[12] = { 'A', 'B','C','D','E','F','a','b','c','d','e','f' };
	char capLetter[6] = { 'A', 'B','C','D','E','F'};
	bool check2 = false;
	int numSwitch = 0;
	char col = ' ';
	int row = 0;
	bool check = true;
	cout << "Do you want row 1 or 2?\n";
	cin >> row;
	while (cin.fail())
	{
		cout << "Try again: ";
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cin >> row;
	}
	if (row > 0 && row < 3)
	{
		cout << "Which seat would you like?(A-F)\n";
		cin >> col;
		for (int i = 0; i < 12; i++)
		{
			if (col == checkLetter[i])
			{
				if (tolower(col))
					col = toupper(col);
				cout << "You have chosen seat " << row << col << endl;
				for (int t = 0; t < 6; t++)
				{
					if (col == capLetter[t])
						numSwitch = i;
				}
				plane[row - 2][numSwitch] = 'X';
				display();
				check2 = true;
				total += 1500;
				ftickets += 1;
				ftotal += 1500;
				cout << "Your total is now $" << total << endl;
				break;
			}
		}
		while (check2 == false)
		{
			cout << "Please choose a seat A-F\n";
			cin >> col;
			for (int i = 0; i < 12; i++)
			{
				if (col == checkLetter[i])
				{
					if (tolower(col))
						col = toupper(col);
					cout << "You have chosen seat " << row << col << endl;
					for (int t = 0; t < 6; t++)
					{
						if (col == capLetter[t])
							numSwitch = i;
					}
					plane[row - 2][numSwitch] = 'X';
					display();
					check2 = true;
					total += 1500;
					ftickets += 1;
					ftotal += 1500;
					cout << "Your total is now $" << total << endl;
					break;
				}
			}
		}
	}
	else
	{
		while (check == true)
		{
			cout << "Please choose 1 or 2" << endl;
			cin >> row;
			while (cin.fail())
			{
				cout << "Try again: ";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cin >> row;
			}
			if (row > 0 && row < 3)
			{
				check = false;
				cout << "Which seat would you like?(A-F)\n";
				cin >> col;
				for (int i = 0; i < 12; i++)
				{
					if (col == checkLetter[i])
					{
						if (tolower(col))
							col = toupper(col);
						cout << "You have chosen seat " << row << col << endl;
						for (int t = 0; t < 6; t++)
						{
							if (col == capLetter[t])
								numSwitch = i;
						}
						plane[row - 2][numSwitch] = 'X';
						display();
						check2 = true;
						total += 1500;
						ftickets += 1;
						ftotal += 1500;
						cout << "Your total is now $" << total << endl;
						break;
					}
				}
				while (check2 == false)
				{
					cout << "Please choose a seat A-F\n";
					cin >> col;
					for (int i = 0; i < 12; i++)
					{
						if (col == checkLetter[i])
						{
							if (tolower(col))
								col = toupper(col);
							cout << "You have chosen seat " << row << col << endl;
							for (int t = 0; t < 6; t++)
							{
								if (col == capLetter[t])
									numSwitch = i;
							}
							plane[row - 2][numSwitch] = 'X';
							display();
							check2 = true;
							total += 1500;
							ftickets += 1;
							ftotal += 1500;
							cout << "Your total is now $" << total << endl;
							break;
						}
					}
				}
			}
		}
	}
}

void business()
{
	//variables
	char checkLetter[12] = { 'A', 'B','C','D','E','F','a','b','c','d','e','f' };
	char capLetter[6] = { 'A', 'B','C','D','E','F' };
	bool check2 = false;
	int numSwitch = 0;
	char col = ' ';
	int row = 0;
	bool check = true;
	cout << "Do you want row 3 or 4?\n";
	cin >> row;
	while (cin.fail())
	{
		cout << "Try again: ";
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cin >> row;
	}
	if (row == 3 || row == 4)
	{
		cout << "Which seat would you like?(A-F)\n";
		cin >> col;
		for (int i = 0; i < 12; i++)
		{
			if (col == checkLetter[i])
			{
				if (tolower(col))
					col = toupper(col);
				cout << "You have chosen seat " << row << col << endl;
				for (int t = 0; t < 6; t++)
				{
					if (col == capLetter[t])
						numSwitch = i;
				}
				plane[row - 2][numSwitch] = 'X';
				display();
				check2 = true;
				total += 700;
				btickets += 1;
				btotal += 700;
				cout << "Your total is now $" << total << endl;
				break;
			}
		}
		while (check2 == false)
		{
			cout << "Please choose a seat A-F\n";
			cin >> col;
			for (int i = 0; i < 12; i++)
			{
				if (col == checkLetter[i])
				{
					if (tolower(col))
						col = toupper(col);
					cout << "You have chosen seat " << row << col << endl;
					for (int t = 0; t < 6; t++)
					{
						if (col == capLetter[t])
							numSwitch = i;
					}
					plane[row - 2][numSwitch] = 'X';
					display();
					check2 = true;
					total += 700;
					btickets += 1;
					btotal += 700;
					cout << "Your total is now $" << total << endl;
					break;
				}
			}
		}
	}
	else
	{
		while (check == true)
		{
			cout << "Please choose 3 or 4" << endl;
			cin >> row;
			while (cin.fail())
			{
				cout << "Try again: ";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cin >> row;
			}
			if (row == 3 || row == 4)
			{
				check = false;
				cout << "Which seat would you like?(A-F)\n";
				cin >> col;
				for (int i = 0; i < 12; i++)
				{
					if (col == checkLetter[i])
					{
						if (tolower(col))
							col = toupper(col);
						cout << "You have chosen seat " << row << col << endl;
						for (int t = 0; t < 6; t++)
						{
							if (col == capLetter[t])
								numSwitch = i;
						}
						plane[row - 2][numSwitch] = 'X';
						display();
						check2 = true;
						total += 700;
						btickets += 1;
						btotal += 700;
						cout << "Your total is now $" << total << endl;
						break;
					}
				}
				while (check2 == false)
				{
					cout << "Please choose a seat A-F\n";
					cin >> col;
					for (int i = 0; i < 12; i++)
					{
						if (col == checkLetter[i])
						{
							if (tolower(col))
								col = toupper(col);
							cout << "You have chosen seat " << row << col << endl;
							for (int t = 0; t < 6; t++)
							{
								if (col == capLetter[t])
									numSwitch = i;
							}
							plane[row - 2][numSwitch] = 'X';
							display();
							check2 = true;
							total += 700;
							btickets += 1;
							btotal += 700;
							cout << "Your total is now $" << total << endl;
							break;
						}
					}
				}
			}
		}
	}
}

void economy()
{
	//variables
	char checkLetter[12] = { 'A', 'B','C','D','E','F','a','b','c','d','e','f' };
	char capLetter[6] = { 'A', 'B','C','D','E','F' };
	bool check2 = false;
	int numSwitch = 0;
	char col = ' ';
	int row = 0;
	bool check = true;
	cout << "Please choose row 5-17?\n";
	cin >> row;
	while (cin.fail())
	{
		cout << "Try again: ";
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cin >> row;
	}
	if (row > 4 && row < 18)
	{
		cout << "Which seat would you like?(A-F)\n";
		cin >> col;
		for (int i = 0; i < 12; i++)
		{
			if (col == checkLetter[i])
			{
				if (tolower(col))
					col = toupper(col);
				cout << "You have chosen seat " << row << col << endl;
				for (int t = 0; t < 6; t++)
				{
					if (col == capLetter[t])
						numSwitch = i;
				}
				plane[row - 2][numSwitch] = 'X';
				display();
				check2 = true;
				total += 200;
				etickets += 1;
				etotal += 200;
				cout << "Your total is now $" << total << endl;
				break;
			}
		}
		while (check2 == false)
		{
			cout << "Please choose a seat A-F\n";
			cin >> col;
			for (int i = 0; i < 12; i++)
			{
				if (col == checkLetter[i])
				{
					if (tolower(col))
						col = toupper(col);
					cout << "You have chosen seat " << row << col << endl;
					for (int t = 0; t < 6; t++)
					{
						if (col == capLetter[t])
							numSwitch = i;
					}
					plane[row - 2][numSwitch] = 'X';
					display();
					check2 = true;
					total += 200;
					etickets += 1;
					etotal += 200;
					cout << "Your total is now $" << total << endl;
					break;
				}
			}
		}
	}
	else
	{
		while (check == true)
		{
			cout << "Please choose 5-17" << endl;
			cin >> row;
			while (cin.fail())
			{
				cout << "Try again: ";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cin >> row;
			}
			if (row > 4 && row < 18)
			{
				check = false;
				cout << "Which seat would you like?(A-F)\n";
				cin >> col;
				for (int i = 0; i < 12; i++)
				{
					if (col == checkLetter[i])
					{
						if (tolower(col))
							col = toupper(col);
						cout << "You have chosen seat " << row << col << endl;
						for (int t = 0; t < 6; t++)
						{
							if (col == capLetter[t])
								numSwitch = i;
						}
						plane[row - 2][numSwitch] = 'X';
						display();
						check2 = true;
						total += 200;
						etickets += 1;
						etotal += 200;
						cout << "Your total is now $" << total << endl;
						break;
					}
				}
				while (check2 == false)
				{
					cout << "Please choose a seat A-F\n";
					cin >> col;
					for (int i = 0; i < 12; i++)
					{
						if (col == checkLetter[i])
						{
							if (tolower(col))
								col = toupper(col);
							cout << "You have chosen seat " << row << col << endl;
							for (int t = 0; t < 6; t++)
							{
								if (col == capLetter[t])
									numSwitch = i;
							}
							plane[row - 2][numSwitch] = 'X';
							display();
							check2 = true;
							total += 200;
							etickets += 1;
							etotal += 200;
							cout << "Your total is now $" << total << endl;
							break;
						}
					}
				}
			}
		}
	}
}

void returnSeat()
{
	//variables
	char checkLetter[12] = { 'A', 'B','C','D','E','F','a','b','c','d','e','f' };
	char capLetter[6] = { 'A', 'B','C','D','E','F' };
	bool check2 = false;
	int numSwitch = 0;
	char col = ' ';
	int row = 0;
	bool check = true;
	display();
	cout << "Please choose row 1-17\n";
	cin >> row;
	while (cin.fail())
	{
		cout << "Try again: ";
		cin.clear();
		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cin >> row;
	}
	if (row > 0 && row < 18)
	{
		cout << "Which seat would you like to return?(A-F)\n";
		cin >> col;
		for (int i = 0; i < 12; i++)
		{
			if (col == checkLetter[i])
			{
				if (tolower(col))
					col = toupper(col);
				cout << "You have chosen to return seat " << row << col << endl;
				for (int t = 0; t < 6; t++)
				{
					if (col == capLetter[t])
						numSwitch = i;
				}
				if (plane[row - 2][numSwitch] == 'X')
				{
					plane[row - 2][numSwitch] = '*';
					display();
					check2 = true;
					if (row > 0 && row < 3)
					{
						total -= 1500;
						ftickets -= 1;
						ftotal -= 1500;
					}
					else if (row > 2 && row < 5)
					{
						total -= 700;
						btickets -= 1;
						btotal -= 700;
					}
					else if (row > 4 && row < 18)
					{
						total -= 200;
						etickets -= 1;
						etotal -= 200;
					}
					cout << "Your total is now $" << total << endl;
					break;
				}
				else
				{
					cout << "You don't own that seat!" << endl;
					check2 = true;
				}
				break;
			}
		}
		while (check2 == false)
		{
			cout << "Please choose a seat A-F\n";
			cin >> col;
			for (int i = 0; i < 12; i++)
			{
				if (col == checkLetter[i])
				{
					if (tolower(col))
						col = toupper(col);
					cout << "You have chosen to return seat " << row << col << endl;
					for (int t = 0; t < 6; t++)
					{
						if (col == capLetter[t])
							numSwitch = i;
					}
					if (plane[row - 2][numSwitch] == 'X')
					{
						plane[row - 2][numSwitch] = '*';
						display();
						check2 = true;
						if (row > 0 && row < 3)
						{
							total -= 1500;
							ftickets -= 1;
							ftotal -= 1500;
						}
						else if (row > 2 && row < 5)
						{
							total -= 700;
							btickets -= 1;
							btotal -= 700;
						}
						else if (row > 4 && row < 18)
						{
							total -= 200;
							etickets -= 1;
							etotal -= 200;
						}
						cout << "Your total is now $" << total << endl;
						break;
					}
					else
					{
						cout << "You don't own that seat!" << endl;
						check2 = true;
					}
					break;
				}
			}
		}
	}
	else
	{
		while (check == true)
		{
			cout << "Please choose 1-17" << endl;
			cin >> row;
			while (cin.fail())
			{
				cout << "Try again: ";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cin >> row;
			}
			if (row > 4 && row < 18)
			{
				check = false;
				cout << "Which seat would you like?(A-F)\n";
				cin >> col;
				for (int i = 0; i < 12; i++)
				{
					if (col == checkLetter[i])
					{
						if (tolower(col))
							col = toupper(col);
						cout << "You have chosen to return seat " << row << col << endl;
						for (int t = 0; t < 6; t++)
						{
							if (col == capLetter[t])
								numSwitch = i;
						}
						if (plane[row - 2][numSwitch] == 'X')
						{
							plane[row - 2][numSwitch] = '*';
							display();
							check2 = true;
							if (row > 0 && row < 3)
							{
								total -= 1500;
								ftickets -= 1;
								ftotal -= 1500;
							}
							else if (row > 2 && row < 5)
							{
								total -= 700;
								btickets -= 1;
								btotal -= 700;
							}
							else if (row > 4 && row < 18)
							{
								total -= 200;
								etickets -= 1;
								etotal -= 200;
							}
							cout << "Your total is now $" << total << endl;
							break;
						}
						else
						{
							cout << "You don't own that seat!" << endl;
							check2 = true;
						}
						break;
					}
				}
				while (check2 == false)
				{
					cout << "Please choose a seat A-F\n";
					cin >> col;
					for (int i = 0; i < 12; i++)
					{
						if (col == checkLetter[i])
						{
							if (tolower(col))
								col = toupper(col);
							cout << "You have chosen to return seat " << row << col << endl;
							for (int t = 0; t < 6; t++)
							{
								if (col == capLetter[t])
									numSwitch = i;
							}
							if (plane[row - 2][numSwitch] == 'X')
							{
								plane[row - 2][numSwitch] = '*';
								display();
								check2 = true;
								if (row > 0 && row < 3)
								{
									total -= 1500;
									ftickets -= 1;
									ftotal -= 1500;
								}
								else if (row > 2 && row < 5)
								{
									total -= 700;
									btickets -= 1;
									btotal -= 700;
								}
								else if (row > 4 && row < 18)
								{
									total -= 200;
									etickets -= 1;
									etotal -= 200;
								}
								cout << "Your total is now $" << total << endl;
								break;
							}
							else
							{
								cout << "You don't own that seat!" << endl;
								check2 = true;
							}
							break;
						}
					}
				}
			}
		}
	}
}