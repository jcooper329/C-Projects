/*
Name: Justin Cooper
Date: 09.20.2018
Desc: Selling services with functions
*/

#include <iostream>
#include <string>
#include <iomanip>

using namespace std;
//functions
void menu();
void getMoney();
int checkout(int& lawn, int& car, int& hw);
int cart(int& lawn, int& car, int& hw);
void coupon1();
//variables
bool couponcheck = false;
bool coupon2Check = false;
double AMOUNT;
int LAWN = 0;
int CAR = 0;
int HWS = 0;
double total;
bool check = true;
int main()
{
	//variables
	int hold = 0;

	getMoney();
	cout << "Welcome to our shop! What would you like to buy?" << endl;
	menu();
	if (check == true)
	checkout(LAWN, CAR, HWS);

	cin >> hold;
	return 0;
}

void menu()
{
	//variables
	int sendchoice = 0;
	int couponchoice = 0;
	bool goAway = false;
	total = 0.0;
	char answer = ' ';
	char answer1 = ' ';
	char ans = ' ';
	int choice = -1;
	int lawns = 0;
	int cars = 0;
	int hw = 0;
	AMOUNT -= AMOUNT * .07;
	cout << "You can spend $" << AMOUNT << endl;
	do
	{
		cout << "\t\t1. Mow Lawn\t$20.00 \n\t\t2. Wash Car\t$29.99 \n\t\t3. Homework\t$70.00\n\t\t4. Cancel \n\t\t0. View Cart\n";
		cin >> choice;
		cout << endl;
		switch (choice)
		{
			case 1: //buy mow lawn
			{
				if (AMOUNT < 20)
				{
					cout << "You don't have enough money for that! Would you like to checkout with what you have?(y/n) ";
					cin >> answer;
					cout << endl;
					if (answer == 'y' || answer == 'Y')
					{
						checkout(lawns, cars, hw);
						goAway = true;
						break;
					}
					else
					goAway = true;
				}
				else if (coupon2Check == false) //check if coupon was used
				{
					cout << "Do you want to use a coupon for 10% off this item?(y/n)\n";
					cin >> answer;
					if (answer == 'y' || answer == 'Y')
					{
						total += (20 - 20 * .1);
						AMOUNT -= (20 - 20 * .1);
						lawns++;
						cout << "That costs $" << 20 - 20 * .1 << " with the coupon." << endl;
						cout << "Mow Lawn has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						coupon2Check = true;
						break;
					}
					else
					{
						total += 20;
						AMOUNT -= 20;
						lawns++;
						cout << "Mow Lawn has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						break;
					}
				}
				else
				{
					total += 20;
					AMOUNT -= 20;
					lawns++;
					cout << "Mow Lawn has been added to your cart. Your total is now: $" << total << endl;
					cout << "You now have $" << AMOUNT << " left to spend." << endl;
					break;
				}
				break;
			}
			case 2: //buy car wash
			{
				if (AMOUNT < 29.99)
				{
					cout << "You don't have enough money for that! Would you like to checkout with what you have? ";
					cin >> answer;
					cout << endl;
					if (answer == 'y' || answer == 'Y')
					{
						checkout(lawns, cars, hw);
						goAway = true;
						break;
					}
					else
						goAway = true;
				}
				else if (coupon2Check == false) //checks if coupon was used
				{
					cout << "Do you want to use a coupon for 10% off this item?(y/n)\n";
					cin >> answer;
					if (answer == 'y' || answer == 'Y')
					{
						total += (29.99 - 29.99 * .1);
						AMOUNT -= (29.99 - 29.99 * .1);
						cars++;
						cout << "That costs $" << 29.99 - 29.99 * .1 << " with the coupon." << endl;
						cout << "Wash Car has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						coupon2Check = true;
						break;
					}
					else
					{
						total += 29.99;
						AMOUNT -= 29.99;
						cars++;
						cout << "Wash Car has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						break;
					}
				}
				else
				{
					total += 29.99;
					AMOUNT -= 29.99;
					cars++;
					cout << "Wash Car has been added to your cart. Your total is now: $" << total << endl;
					cout << "You now have $" << AMOUNT << " left to spend." << endl;
					break;
				}
				break;
			}
			case 3: //buy homework
			{
				if (AMOUNT < 70)
				{
					cout << "You don't have enough money for that! Would you like to checkout with what you have? ";
					cin >> answer;
					cout << endl;
					if (answer == 'y' || answer == 'Y')
					{
						checkout(lawns, cars, hw);
						goAway = true;
						break;
					}
					else
						goAway = true;
				}
				else if (coupon2Check == false)//checks if coupon was used
				{
					cout << "Do you want to use a coupon for 10% off this item?\n";
					cin >> answer;
					if (answer == 'y' || answer == 'Y')
					{
						total += (70 - 70 * .1);
						AMOUNT -= (70 - 70 * .1);
						hw++;
						cout << "That costs $" << 70 - 70 * .1 << " with the coupon." << endl;
						cout << "Homework has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						coupon2Check = true;
						break;
					}
					else
					{
						total += 70;
						AMOUNT -= 70;
						hw++;
						cout << "Homework has been added to your cart. Your total is now: $" << total << endl;
						cout << "You now have $" << AMOUNT << " left to spend." << endl;
						break;
					}
				}
				else
				{
					total += 70;
					AMOUNT -= 70;
					hw++;
					cout << "Homework has been added to your cart. Your total is now: $" << total << endl;
					cout << "You now have $" << AMOUNT << " left to spend." << endl;
					break;
				}
				break;
			}
			case 4: //cancel order
			{
				cout << "You chose cancel! See you later.";
				goAway = true;
				check = false;
				cout << endl;
				break;
			}
			case 0: //view cart
			{
				cart(lawns,cars,hw);
				cout << endl;
				cout << "Would you like to checkout?(y/n)\n";
				cin >> answer;
				if (answer == 'y' || answer == 'Y')
				goAway = true;
				else
					check = false;
				break;
			}
			default:
			{
				while (choice < 0 || choice > 4)//checks if valid choice
				{
					cout << "Invalid choice! Please enter a number 0-3!\n";
					cin >> choice;
					cout << endl;
				}
				break;
			}
		}
		if (goAway == false)
		{
			cout << "Would you like to buy another item?(y/n)\n";
			cin >> answer1;
			if (answer1 != 'y' && answer1 != 'Y')
			{
				cout << "Would you like to checkout?(y/n)\n";
				cin >> answer1;
				if (answer1 == 'y' || answer1 == 'Y')
				{
					if (coupon2Check == false)
					{
						cout << "Would you like to use a coupon for 5% off your entire purchase? (Y/y for yes)\n";
						cin >> ans;
						if (ans == 'y' || ans == 'Y')
						{
							total -= total * .05;
							coupon2Check = true;
						}
						else
							coupon2Check = true;
					}
					else
						check = true;
				}
				else
					check = false;
			}
			else
				answer = 'y';
			cout << endl;
		}
		else
		{
			answer = 'n';
			coupon2Check = true;
		}
	} while (answer == 'y' || answer == 'Y');
	if (coupon2Check == false)//checks if coupon was used already
	{
		cout << "Would you like to use a coupon for 5% off your entire purchase? (Y/y for yes)\n";
		cin >> ans;
		if (ans == 'y' || ans == 'Y')
			total -= total * .05;
	}
	CAR = cars;
	LAWN = lawns;
	HWS = hw;
}

void getMoney() //asks how much money they have
{
	cout << "How much money do you have? ";
	cin >> AMOUNT;
	while (AMOUNT < 0)
	{
		cout << "Invalid amount. You can't have less than 0 dollars.\nPlease enter a new amount. ";
		cin >> AMOUNT;
		cout << endl;
	}

	if (cin.fail())
	{
		cout << "Please enter a number. ";
		cin >> AMOUNT;
		cout << endl;
	}

}

int checkout(int& lawn, int& car, int& hw)//checkout stuff
{
	setprecision(2);
	cout << "Your Items\n" << endl;
	cout << "Lawns: " << lawn << endl;
	cout << "Cars: " << car << endl;
	cout << "Homeworks: " << hw << endl;
	cout << endl;
	cout << "Your total is: $" << total << " before tax." << endl;
	cout << "Tax is: 7%" << endl;
	cout << "With tax your total is: $" << setprecision(2) << total * 1.07 << endl;
	cout << "Please pay now!";
	return 0;
}

int cart(int& lawn, int& car, int& hw)//cart of your stuff
{
	char answer = ' ';
	int choice = 0;
	cout << "______________________________" << endl;
	cout << "             Cart             " << endl;
	cout << "______________________________" << endl;
	cout << "           1. Lawns: " << lawn << endl;
	cout << "           2. Cars: " << car << endl;
	cout << "           3. Homeworks: " << hw << endl;
	cout << "\n\n\n";
	cout << "Would you like to return anything?";
	cin >> answer;
	if (answer == 'y' || answer == 'Y')
	{
		cout << "Please select which number you would like to return: ";
		cin >> choice;
		
	}
	return 0;
}

void coupon1()
{
	total *= .25;
}
