/*
Name: Justin Cooper
Date: 09.11.2018
Desc: Trump Burgers resturaunt
*/
#include <iostream>
#include <cstdlib> //c standard library
#include <ctime> //c time
#include <iomanip>

using namespace std;



int main()
{
	//variables
	int choice = 0;
	char answer;
	int hold;
	int decision1 = 0;
	int decision2 = 0;
	int decision3 = 0;
	double total = 0.0;
	double num = 0.0;
	double tax = 0.0;
	double cost = 0.0;
	int checkout = 0;





	do
	{//start while
		cout << "Welcome to Trump Burgers! \n Please choose which menu you would like." << endl;
		cout << "*************************" << endl;
		cout << "***   1. Breakfast    ***" << endl;
		cout << "***   2. Lunch        ***" << endl;
		cout << "***   3. Dinner       ***" << endl;
		cout << "*************************" << endl;
		cin >> choice;
		cout << endl;
		cout << endl;

		switch (choice)
		{ //open switch
		case 1: //Breakfast
		{ //open case 1
			cout << "************************************************" << endl;
			cout << "***   1. Bacon Egg and Cheese Burger $2.50   ***" << endl;
			cout << "***   2. Cereal Burger $4.50                 ***" << endl;
			cout << "***   3. Omelette Burger $7.50               ***" << endl;
			cout << "************************************************" << endl;
			cin >> decision1;
			switch (decision1)
			{ // open switch 2
			case 1:
			{ // open case
				cout << "Are you sure you want the Bacon Egg and Cheese Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $2.50" << endl;
					total += 2.50;
				} // end cost
				break;
			} // close case
			case 2:
			{ // open case
				cout << "Are you sure you want the Cereal Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $4.50" << endl;
					total += 4.50;
				} // end cost
				break;
			} // close case
			case 3:
			{ // open case
				cout << "Are you sure you want the Omelette Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $7.50" << endl;
					total += 7.50;
				} // end cost
				break;
			} // close case
			} // close switch 2
			break;
		}//close case 1
		case 2: //Lunch
		{ //open case 2
			cout << "**********************************************" << endl;
			cout << "***   1. Classic Burger  $10.00            ***" << endl;
			cout << "***   2. Million Dollar Burger $1,000,000  ***" << endl;
			cout << "***   3. Fortnite Burger $13.75               ***" << endl;
			cout << "*******************************************" << endl;
			cin >> decision2;
			switch (decision2)
			{ // open switch 2
			case 1:
			{ // open case
				cout << "Are you sure you want the Classic Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $10.00" << endl;
					total += 10.00;
				} // end cost
				break;
			} // close case
			case 2:
			{ // open case
				cout << "Are you sure you want the Million Dollar Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $1,000,000.00" << endl;
					total += 1000000.00;
				} // end cost
				break;
			} // close case
			case 3:
			{ // open case
				cout << "Are you sure you want the Fortnite Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $13.75" << endl;
					total += 13.75;
				} // end cost
				break;
			} // close case
			} // close switch 2
			break;
		} // close case 2
		case 3: // Dinner
		{ //open case 3
			cout << "*******************************************" << endl;
			cout << "***   1. Bacon Burger $25.00            ***" << endl;
			cout << "***   2. Seafood Burger $100.00         ***" << endl;
			cout << "***   3. Trump Burger  $45.35           ***" << endl;
			cout << "*******************************************" << endl;
			cin >> decision3;
			switch (decision3)
			{ // open switch 3
			case 1:
			{ // open case
				cout << "Are you sure you want the Bacon Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $25.00" << endl;
					total += 25.00;
				} // close cost
				break;
			} // close case
			case 2:
			{ // open case
				cout << "Are you sure you want the Seafood Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $100.00" << endl;
					total += 100.00;
				} // end cost
				break;
			} // close case
			case 3:
			{ // open case
				cout << "Are you sure you want the Trump Burger? ";
				cin >> answer;
				cout << endl;
				if (answer == 'y' || answer == 'Y')
				{ // start cost
					cout << "Thank you for your purchase! That will be $45.35" << endl;
					total += 45.35;
				} // end cost
				break;
			} // close case


			} // close switch 3
			break;
		}//close case 3

		default:
		{ // start default
			cout << "Please leave the establishment." << endl;
			break;
		} // end default


		} // close switch

		cout << showpoint << fixed << setprecision(2);

		while (!checkout)
		{
			srand(time(0));
			num = rand() % 100;
			tax = num / 100;
			cost = total += tax;

			answer = ' ';
			cout << "Would you like to make another order?" << endl;
			cin >> answer;
			if (answer = 'N' || answer == 'n');
			cout << "Your total is: $" << cost << "! Have a nice day!" << endl;
			break;
		}

	} while (answer == 'Y' || answer == 'y'); //end while
	cin >> hold;
	return 0;
}
