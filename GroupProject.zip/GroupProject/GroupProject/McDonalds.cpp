/*
Name:		Justin Cooper
Date:		08.21.2018
Description:  McDonalds menu and prices
*/

#include <iostream>

using namespace std;

//constant variables
const double BIGMAC = 20.00;
const double CHICKENNUGGETS = 30.00;
const double FILETOFISH = 15.00;
const double FRIES = 25.00;
int main()
{
	//variables
	int order = 0;
	double total = 0.0;
	char ans = 'y';
	int check = 1;
	int numItems = 0;
	int hold;

	//user interaction
	cout << "1.  Big Mac" << endl;
	cout << "2.  Chicken Nuggets" << endl;
	cout << "3.  Filet O fish" << endl;
	cout << "4.  Fries" << endl;
	cout << "Enter a number 1-4 that you would like to order: " << endl;
	cin >> order;

	if (order == 1)
	{
		total += BIGMAC;
		numItems++;
	}
	if (order == 2)
	{
		total += CHICKENNUGGETS;
		numItems++;
	}
	if (order == 3)
	{
		total += FILETOFISH;
		numItems++;
	}
	if (order == 4)
	{
		total += FRIES;
		numItems++;
	}
	//check of order is on menu
	if (order > 4 || order < 1)
		check = 0;
	//loops if order isn't on menu
	while (check == 0)
	{
		cout << "Your order must be between 1 and 4. Please enter your order number: " << endl;
		cin >> order;

		if (order == 1)
		{
			total += BIGMAC;
			numItems++;
		}
		if (order == 2)
		{
			total += CHICKENNUGGETS;
			numItems++;
		}
		if (order == 3)
		{
			total += FILETOFISH;
			numItems++;
		}
		if (order == 4)
		{
			total += FRIES;
			numItems++;
		}

		if (order > 0 && order < 5)
			check = 1;
	}

	cout << "Your total is $" << total << ". You ordered " << numItems << " items." << endl;
	cout << "Would you like to order another item? (Enter Y or N) " << endl;
	cin >> ans;
	//loops until they dont want to order another item
	while (ans == 'Y' || ans == 'y')
	{
		cout << "Choose another item: " << endl;
		cin >> order;

		if (order == 1)
		{
			total += BIGMAC;
			numItems++;
		}
		if (order == 2)
		{
			total += CHICKENNUGGETS;
			numItems++;
		}
		if (order == 3)
		{
			total += FILETOFISH;
			numItems++;
		}
		if (order == 4)
		{
			total += FRIES;
			numItems++;
		}

		if (order > 4 || order < 1)
			check = 0;
		cout << "Your total is $" << total << ". You ordered "<< numItems << " items." << endl;
		cout << "Would you like to order another item? (Enter Y or N) " << endl;
		cin >> ans;
		while (check == 0)
		{
			cout << "Your order must be between 1 and 4. Please enter your order number: " << endl;
			cin >> order;

			if (order == 1)
			{
				total += BIGMAC;
				numItems++;
			}
			if (order == 2)
			{
				total += CHICKENNUGGETS;
				numItems++;
			}
			if (order == 3)
			{
				total += FILETOFISH;
				numItems++;
			}
			if (order == 4)
			{
				total += FRIES;
				numItems++;
			}

			if (order > 0 && order < 5)
				check = 1;
		}
		 
	}


	cout << "Your total is $" << total << ". You ordered " << numItems << " items. Please pay now." << endl;
	cin >> hold;
	return 0;
}